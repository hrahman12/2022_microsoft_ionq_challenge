# QATS-quantum cats (QUQATS team)
#iQuHACK quantum computing video game

    Skill level: Beginner 
    Education
    Understanding the phases of circuits and qubits
    Anybody with any background can understand through problem solving how to create a circuit without being explicit with details
    
    Reason for the game: Cats are everywhere in Quantum Computing! Schrodingers cat! Boxes are everywhere too! Why not use those to understand QC?
    
    We start out with the cats in superpostion (green cats) which are the qubits.
    We use the Draper Method for addition and subtraction. 
    By using gates in the circuits we can change the color of the cats (i.e. the states of the cats).
    The goal is to find the original cats(purple) from the changed cats(green).


    Rules: In order to find the right cats we have a certain number of boxes with a unique rotation.
    You can choose to use more or less boxes depending on the structure of the circuit.
    
    IQUHACK experience: The team orginally wasn't familiar with azure, but through help of mentors and outside resources we found ways to get the ionq backends to       work. We also used pygame for the animation and had fun designing the mechanics. Getting the idea into tangible code was an exciting challenge 
    
    
